﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTOs
{
    public class LookUpDTO
    {
        public int Id { get; set; }
        public char value { get; set; }
        public int IntValue { get; set; }
        public bool BoolValue { get; set; }
        public string name { get; set; }
    }
}
