﻿
namespace DTOs
{
    public class Product
    {
        public int Id { get; set; }
        public string ItemName { get; set; }
        public string ItemDescription { get; set; }
        public double PricePerUnit { get; set; }

    }
}
