﻿namespace DTOs
{
    public class TransactionItem
    {
        public int Id { get; set; }
        public int? ItemId { get; set; }
        public Product? Product { get; set; }
        public string? ItemDescription { get; set; }
        public double? Amount { get; set; }
        public int? Quantity { get; set; }
        public double? Total { get; set; }
        public string? TranxId { get; set; }
    }
}
