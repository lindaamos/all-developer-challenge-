﻿
namespace DTOs
{
    public class Transaction
    {
        public int Id { get; set; }
        public string? InvoiceNumber { get; set; }
        public DateTime TranxDate { get; set; }
        public double TotalAmount { get; set; }
        public string? DoneBy { get; set; }
        public string? Currency { get; set; }
        public string? TransactionType { get; set; }
        public DateTime ExpiryDate { get; set; }
        public int CustomerId { get; set; }
        public Customer? Customer { get; set; }
        public double Taxable { get; set; }
        public double TaxRate { get; set; }
        public double TaxDue { get; set; }
        public double Other { get; set; }
        public List<TransactionItem>? Items { get; set; }   

    }
}
