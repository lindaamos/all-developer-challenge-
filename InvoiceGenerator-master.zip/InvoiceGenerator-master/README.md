# InvoiceGenerator
Requirements
---Visual STudio 2022
---.NET 6
---MS SQL Server 2019
