﻿using System.Data;
using System.Data.SqlClient;

namespace API.Services
{
    public class SqlHelperMethods : ISqlHelperMethods
    {
        private static SqlConnection con;
        private IConfiguration _configuration;
        public SqlHelperMethods(IConfiguration configuration)
        {
            _configuration = configuration;
            con = new SqlConnection(_configuration.GetConnectionString("DefaultConnection"));
        }

        public DataSet _buildDataSet(string sqlString, params SqlParameter[] parameters)
        {
            DataSet result = new DataSet();

            if (!string.IsNullOrEmpty(sqlString))
            {
            
                using (SqlCommand sqlCmd = new SqlCommand(sqlString, con))
                using (SqlDataAdapter sqlDad = new SqlDataAdapter(sqlCmd))
                {
                    if(parameters.Length > 0)
                        sqlCmd.Parameters.AddRange(parameters);
                            
                    sqlDad.Fill(result, "Table");
                }
            }

            return result;
        }

        public int executeSqlTransaction(List<string> arrCommands)
        {
          
            using (SqlCommand command = con.CreateCommand())
            {
                // Open connection

                con.Open();

                // Start a local transaction.

                using (command.Transaction = con.BeginTransaction())
                {

                    try
                    {
                        for (int i = 0; i < arrCommands.Count; i++)
                        {
                            command.CommandText = arrCommands[i];
                            if (!string.IsNullOrEmpty(command.CommandText))
                            {
                            
                                command.ExecuteNonQuery();
                            }
                        }

                        // Attempt to commit the transaction.
                        command.Transaction.Commit();

                        con.Close();

                        return 1;

                     

                    }
                    catch (Exception ex)
                    {
                        try
                        {
                            if (command.Transaction != null)
                                command.Transaction.Rollback();

                            con.Close();
                        }
                        catch (Exception ex2)
                        {
                            // This catch block will handle any errors that may have occurred
                            // on the server that would cause the rollback to fail, such as
                            // a closed connection.
                        }
                 
                        
                        return -1;

                    }
               
                }
            }
         
        }
    }
}
