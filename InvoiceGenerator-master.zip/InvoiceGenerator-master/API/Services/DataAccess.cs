﻿using System.Data;
using System.Data.SqlClient;
using DTOs;

namespace API.Services
{
    public class DataAccess : IDataAccess
    {
        private ISqlHelperMethods sqlHelper;

        public DataAccess(ISqlHelperMethods sqlHelper)
        {
            this.sqlHelper = sqlHelper;
        }


        public List<Product> getProducts()
        {
            string getProductQuery = "SELECT Id,ItemName,ItemDescription,PricePerUnit  FROM tblItem";

            var productDataset = sqlHelper._buildDataSet(getProductQuery);

            var productList = productDataset.Tables[0].AsEnumerable()
                .Select(dataRow => new Product
                {
                    Id = dataRow.Field<int>("Id"),
                    ItemName = dataRow.Field<string>("ItemName") ?? "",
                    ItemDescription = dataRow.Field<string>("ItemDescription") ?? "",
                    PricePerUnit = dataRow.Field<double>("PricePerUnit"),
                }).ToList();

            return productList;
        }

        public Transaction GetInvoice(string InvoiceNumber)
        {
            string SQL =
                "SELECT Transactions.CustomerId, Transactions.TranxDate, Transactions.TotalAmount, Transactions.InvoiceNumber, Transactions.DoneBy, Transactions.Currency, Transactions.TransactionType, Transactions.ExpiryDate," +
                "tblCustomer.CustomerName, tblCustomer.CompanyName, tblCustomer.AddressLine1, tblCustomer.AddressLine2, tblCustomer.City, tblCustomer.ZipCode, tblCustomer.PhoneNumber" +
                $" FROM tblCustomer INNER JOIN Transactions ON tblCustomer.Id = Transactions.CustomerId where Transactions.InvoiceNumber = '{InvoiceNumber}'";

            var transactionItemsQuery =
                "SELECT tblItem.ItemDescription,  tblTransactionItems.Id, tblTransactionItems.Amount, tblTransactionItems.Quantity, tblTransactionItems.Total, tblTransactionItems.TranxId" +
                $" FROM tblTransactionItems INNER JOIN tblItem ON tblTransactionItems.ItemId = tblItem.Id where tblTransactionItems.TranxId = '{InvoiceNumber}'";

            var transactionDataSet = sqlHelper._buildDataSet(SQL);

            var transaction = new Transaction
            {
                InvoiceNumber = transactionDataSet.Tables[0].Rows[0]["InvoiceNumber"].ToString(),
                TranxDate = !String.IsNullOrEmpty(transactionDataSet.Tables[0].Rows[0]["TranxDate"].ToString())
                    ? Convert.ToDateTime(transactionDataSet.Tables[0].Rows[0]["TranxDate"].ToString())
                    : new DateTime(),
                TotalAmount = !String.IsNullOrEmpty(transactionDataSet.Tables[0].Rows[0]["TotalAmount"].ToString())
                    ? Convert.ToDouble(transactionDataSet.Tables[0].Rows[0]["TotalAmount"].ToString())
                    : 0.0,
                DoneBy = transactionDataSet.Tables[0].Rows[0]["DoneBy"].ToString(),
                Currency = transactionDataSet.Tables[0].Rows[0]["Currency"].ToString(),
                TransactionType = transactionDataSet.Tables[0].Rows[0]["TransactionType"].ToString(),
                ExpiryDate = !String.IsNullOrEmpty(transactionDataSet.Tables[0].Rows[0]["ExpiryDate"].ToString())
                    ? Convert.ToDateTime(transactionDataSet.Tables[0].Rows[0]["ExpiryDate"].ToString())
                    : new DateTime(),
                CustomerId = !String.IsNullOrEmpty(transactionDataSet.Tables[0].Rows[0]["CustomerId"].ToString())
                    ? Convert.ToInt32(transactionDataSet.Tables[0].Rows[0]["CustomerId"].ToString())
                    : 0,
            };

            transaction.Customer = new Customer()
            {
                Id = !String.IsNullOrEmpty(transactionDataSet.Tables[0].Rows[0]["CustomerId"].ToString())
                    ? Convert.ToInt32(transactionDataSet.Tables[0].Rows[0]["CustomerId"].ToString())
                    : 0,
                CustomerName = transactionDataSet.Tables[0].Rows[0]["CustomerName"].ToString() ?? "",
                CompanyName = transactionDataSet.Tables[0].Rows[0]["CompanyName"].ToString() ?? "",
                AddressLine1 = transactionDataSet.Tables[0].Rows[0]["AddressLine1"].ToString() ?? "",
                AddressLine2 = transactionDataSet.Tables[0].Rows[0]["AddressLine2"].ToString() ?? "",
                City = transactionDataSet.Tables[0].Rows[0]["City"].ToString() ?? "",
                ZipCode = transactionDataSet.Tables[0].Rows[0]["ZipCode"].ToString() ?? "",
                PhoneNumber = transactionDataSet.Tables[0].Rows[0]["PhoneNumber"].ToString() ?? "",
            };


            var transactionitemDataSet = sqlHelper._buildDataSet(transactionItemsQuery);

            transaction.Items = transactionitemDataSet.Tables[0].AsEnumerable()
                .Select(dataRow => new TransactionItem()
                {
                    Id = dataRow.Field<int>("Id"),
                    ItemDescription = dataRow.Field<string>("ItemDescription") ?? "",
                    Amount = dataRow.Field<double>("Amount"),
                    Quantity = dataRow.Field<int>("Quantity"),

                    //Can be autocalculated
                    Total = dataRow.Field<double>("Total"),
                }).ToList();

            return transaction;

        }

        public List<Customer> getCustomer()
        {
            string getCustomerQuery =
                "SELECT Id,CustomerName,CompanyName,AddressLine1,AddressLine2,City,ZipCode,PhoneNumber FROM dbo.tblCustomer";

            var customerDataset = sqlHelper._buildDataSet(getCustomerQuery);

            var customerList = customerDataset.Tables[0].AsEnumerable()
                .Select(dataRow => new Customer
                {
                    Id = dataRow.Field<int>("Id"),
                    CustomerName = dataRow.Field<string>("CustomerName") ?? "",
                    CompanyName = dataRow.Field<string>("CompanyName") ?? "",
                    AddressLine1 = dataRow.Field<string>("AddressLine1") ?? "",
                    AddressLine2 = dataRow.Field<string>("AddressLine2") ?? "",
                    City = dataRow.Field<string>("City") ?? "",
                    ZipCode = dataRow.Field<string>("ZipCode") ?? "",
                    PhoneNumber = dataRow.Field<string>("PhoneNumber") ?? "",
                }).ToList();

            return customerList;
        }

        public int PostInvoice(Transaction transaction)
        {
            List<string> stringcommands = new List<string>();

            string transactionQuery =
                "INSERT INTO Transactions([TranxDate],[TotalAmount],[InvoiceNumber],[DoneBy]" +
                $",[Currency],[TransactionType],[ExpiryDate],[CustomerId],[Taxable],[TaxRate],[TaxDue],[Other])  VALUES ('{transaction.TranxDate}'" +
                $", {transaction.TotalAmount}, '{transaction.InvoiceNumber}', '{transaction.DoneBy}', '{transaction.Currency}'" +
                $",'{transaction.TransactionType}', '{transaction.ExpiryDate}', '{transaction.CustomerId}', {transaction.Taxable}, {transaction.TaxRate}, {transaction.TaxDue}, {transaction.Other}) ";

            stringcommands.Add(transactionQuery);

            foreach (var transactionItem in transaction.Items)
            {
                string transactionitemquery =
                    "INSERT INTO tblTransactionItems ([ItemId],[Amount],[Quantity],[Total],[TranxId]) VALUES " +
                    $"( {transactionItem.ItemId}, {transactionItem.Amount}, {transactionItem.Quantity}, {transactionItem.Total}, '{transaction.InvoiceNumber}')";
                stringcommands.Add(transactionitemquery);
            }

            return sqlHelper.executeSqlTransaction(stringcommands);
        }
    }
}