﻿using DTOs;

namespace DTOs
{
    public interface IDataAccess
    {
        List<Product> getProducts();
        Transaction GetInvoice(string InvoiceNumber);
        List<Customer> getCustomer();
        int PostInvoice(Transaction transaction);
    }
}
