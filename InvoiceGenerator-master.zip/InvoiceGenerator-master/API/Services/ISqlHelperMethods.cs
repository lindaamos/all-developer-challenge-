﻿using System.Data;
using System.Data.SqlClient;

namespace API.Services
{
    public interface ISqlHelperMethods
    {
        DataSet _buildDataSet(string sqlString, params SqlParameter[] parameters);
        int executeSqlTransaction(List<string> arrCommands);
    }
}
