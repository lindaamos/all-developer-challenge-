﻿
using API.Services;
using DTOs;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransactionController : ControllerBase
    {
        private readonly IDataAccess dataAccess;

        public TransactionController(IDataAccess dataAccess)
        {
            this.dataAccess = dataAccess;
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult AddTransaction([FromBody] Transaction transaction)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if(transaction == null)
                return BadRequest("Invalid Transaction");


            try
            {

                if (String.IsNullOrEmpty(transaction.InvoiceNumber))
                {
                    //Generate a system generated Invoice Number
                    var guid = Guid.NewGuid().ToString();
                    transaction.InvoiceNumber = guid;
                }
             

                var result = dataAccess.PostInvoice(transaction);
                return Ok(result);
            }
            catch (Exception e)
            {
                return Ok(e.Message);
            }

        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult GetTransaction(string InvoiceNumber)
        {
            try
            {
                var transaction = dataAccess.GetInvoice(InvoiceNumber);
                return Ok(transaction);
            }
            catch (Exception e)
            {
                return Ok(e.Message);
            }

        }

    }
}
