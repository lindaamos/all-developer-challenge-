﻿

using DTOs;

namespace FrontEnd.Services
{
    public interface IDataService
    {
        IGenericService<Customer> CustomerService { get; }
        IGenericService<Product> ProductService { get; }
        IGenericService<Transaction> transactionService { get; }
        IGenericService<TransactionItem> transactionItemService { get; }
    }
}