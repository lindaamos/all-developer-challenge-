﻿using System.Net.Http;
using DTOs;


namespace FrontEnd.Services
{
    public class DataService : IDataService
    {
        private readonly HttpClient httpClient;

        private IGenericService<Customer> _CustomerService { get; }
        private IGenericService<Product> _ProductService { get; }
        private IGenericService<Transaction> _transactionService { get; }
        private IGenericService<TransactionItem> _transactionItemService { get; }
        public DataService(HttpClient httpClient)
        {
            this.httpClient = httpClient;
        }

        public IGenericService<Customer> CustomerService => _CustomerService ?? new GenericService<Customer>(httpClient);
        public IGenericService<Product> ProductService => _ProductService ?? new GenericService<Product>(httpClient);
        public IGenericService<Transaction> transactionService => _transactionService ?? new GenericService<Transaction>(httpClient);
        public IGenericService<TransactionItem> transactionItemService => _transactionItemService ?? new GenericService<TransactionItem>(httpClient);
       
    }
}
