﻿using DTOs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace FrontEnd.Services
{
    public class GenericService<T> : IGenericService<T> where T : class
    {
        private readonly HttpClient httpClient;

        public GenericService(HttpClient httpClient)
        {
            this.httpClient = httpClient;
        }

        public async Task<int> Add(string uri, T entity)
        {

            var response = await httpClient.PostAsync(uri, JsonContent.Create(entity));
            var content = await response.Content.ReadAsStringAsync();
            if (response.IsSuccessStatusCode)
            {
                return 1;
            }
            else
            {
                Console.WriteLine(content);
                var ex = new Exception(content);
                throw ex;
            }
        }

        public async Task<int> Delete(string uri)
        {
            var response = await httpClient.DeleteAsync(uri);
            var content = await response.Content.ReadAsStringAsync();
            if (response.IsSuccessStatusCode)
            {

                return Convert.ToInt32(content);
            }
            else
            {
                Console.WriteLine(content);
                var ex = new Exception(content);
                throw ex;
            }
        }

        public async Task<T> Get(string uri)
        {
            var response = await httpClient.GetAsync(uri);
            var content = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                var entity = JsonConvert.DeserializeObject<T>(content);
                return entity;
            }
            else
            {
                Console.WriteLine(content);
                var ex = new Exception(content);
                throw ex;
            }
        }

        public async Task<IEnumerable<T>> GetAll(string uri)
        {
            var response = await httpClient.GetAsync(uri);
            var content = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                var farms = JsonConvert.DeserializeObject<IEnumerable<T>>(content);
                return farms;
            }
            else
            {
                Console.WriteLine(content);
                var ex = new Exception(content);
                throw ex;
            }
        }
        public async Task<T> Update(string uri, T entity)
        {
            var response = await httpClient.PutAsJsonAsync(uri, entity);
            var content = await response.Content.ReadAsStringAsync();
            if (response.IsSuccessStatusCode)
            {
                var updatedfarm = JsonConvert.DeserializeObject<T>(content);
                return updatedfarm;
            }
            else
            {
                Console.WriteLine(content);
                var ex = new Exception(content);
                throw ex;
            }
        }
    }
}
