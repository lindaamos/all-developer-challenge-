﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace FrontEnd.Services
{
    public interface IGenericService<T> where T : class
    {
        public Task<int> Add(string uri, T entity);
        public Task<T> Update(string uri, T entity);
        public Task<T> Get(string uri);
        public Task<int> Delete(string uri);
        public Task<IEnumerable<T>> GetAll(string uri);
    }
}
