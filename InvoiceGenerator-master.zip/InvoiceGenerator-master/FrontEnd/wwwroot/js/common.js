﻿window.ShowToastr = (type, message) => {
    if (type === 'success') {
        toastr.success(message, 'Operation Successful',
            {
                timeOut: 5000
            });
    }

    if (type === 'warning') {
        toastr.warning(message, 'Alert');
    }

    if (type === 'error') {
        toastr.error(message, 'Operation Failed');
    }
}

window.ShowSweetAlert = (type, message) => {
    if (type === 'success') {

        Swal.fire(
            'Success Notification',
            message,
            'success'
        );
    }

    if (type === 'error') {
        Swal.fire(
            'Error Notification',
            message,
            'error'
        );
    }
}

window.LoadDatatable = (tablename) => {

    //    $(document).ready(function () {
    //        $(table).DataTable();
    //    
    //    });

    $(document).ready(function () {
//        var table = $(tablename).DataTable({
//            "columnDefs": [{
//                "visible": false,
//                "targets": 2
//            }],
//            "order": [
//                [2, 'asc']
//            ],
//            "displayLength": 25,
//            "drawCallback": function (settings) {
//                var api = this.api();
//                var rows = api.rows({
//                    page: 'current'
//                }).nodes();
//                var last = null;
//                api.column(2, {
//                    page: 'current'
//                }).data().each(function (group, i) {
//                    if (last !== group) {
//                        $(rows).eq(i).before('<tr class="group"><td colspan="5">' + group + '</td></tr>');
//                        last = group;
//                    }
//                });
//            }
//        });
//
//        // Order by the grouping
//        $(tablename + ' tbody').on('click', 'tr.group', function () {
//            var currentOrder = table.order()[0];
//            if (currentOrder[0] === 2 && currentOrder[1] === 'asc') {
//                table.order([2, 'desc']).draw();
//            } else {
//                table.order([2, 'asc']).draw();
//            }
//        });

        $('#livestocklist').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ]
        });

    });

}

function LoadDatatableExports(tablename) {

    $(tablename).DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    });

}

function opentab(tabid) {
    $('[href=' + tabid +' ]').tab('show');
}

function ShowDeleteConfirmationModal() {
    $('#deleteConfirmationModal').modal('show');
}

function HideDeleteConfirmationModal() {
    $('#deleteConfirmationModal').modal('hide');
}



window.dropifymethods = {
    Initiate: function () {
     /*   $('.dropify').dropify();*/

        $('.dropify').dropify({
            messages: {
                'default': 'Drag and drop here or click here',
                'replace': 'Drag and drop or click to replace',
                'remove': 'Remove',
                'error': 'Ooops, something wrong happended.'
            },
            tpl: {
                wrap: '<div class="dropify-wrapper"></div>',
                loader: '<div class="dropify-loader"></div>',
                message: '<div class="dropify-message"><span class="file-icon" /> <h6>{{ default }}</h6></div>',
                preview: '<div class="dropify-preview"><span class="dropify-render"></span><div class="dropify-infos"><div class="dropify-infos-inner"><p class="dropify-infos-message">{{ replace }}</p></div></div></div>',
                filename: '<p class="dropify-filename"><span class="file-icon"></span> <span class="dropify-filename-inner"></span></p>',
                clearButton: '<button type="button" class="dropify-clear">{{ remove }}</button>',
                errorLine: '<p class="dropify-error">{{ error }}</p>',
                errorsContainer: '<div class="dropify-errors-container"><ul></ul></div>'
            }
        });
    }
    
}