﻿using Microsoft.JSInterop;

namespace FrontEnd.Helpers
{
    public static class JsRuntimeExtension
    {
        public static async ValueTask ToastrSuccess(this IJSRuntime JsRuntime, string message)
        {
            await JsRuntime.InvokeVoidAsync("ShowToastr", "success", message);
        }

        public static async ValueTask ToastrWarning(this IJSRuntime JsRuntime, string message)
        {
            await JsRuntime.InvokeVoidAsync("ShowToastr", "warning", message);
        }

        public static async ValueTask LoadDropify(this IJSRuntime JsRuntime)
        {
            await JsRuntime.InvokeVoidAsync("dropifymethods.Initiate");
        }

        public static async ValueTask ToastrError(this IJSRuntime JsRuntime, string message)
        {
            await JsRuntime.InvokeVoidAsync("ShowToastr", "error", message);
        }

        public static async ValueTask MessageError(this IJSRuntime JsRuntime, string message)
        {
            await JsRuntime.InvokeVoidAsync("ShowSweetAlert", "error", message);
        }

        public static async ValueTask MessageSuccess(this IJSRuntime JsRuntime, string message)
        {
            await JsRuntime.InvokeVoidAsync("ShowSweetAlert", "success", message);
        }

        public static async ValueTask LoadDataTable(this IJSRuntime JsRuntime, string tablename)
        {
            // await JSRuntime.InvokeAsync<object>("LoadDatatable", new[] { $"{tablename}" });

            await JsRuntime.InvokeVoidAsync("LoadDatatable", tablename);
        }

        public static async ValueTask LoadDataTableExports(this IJSRuntime JsRuntime, string tablename)
        {
            await JsRuntime.InvokeVoidAsync("LoadDatatableExports", tablename);
        }

        public static async ValueTask ShowTab(this IJSRuntime JsRuntime, string tabname)
        {
            await JsRuntime.InvokeVoidAsync("opentab", tabname);
        }

       
    }
}
