﻿using System.Collections;
using DTOs;
using System.Collections.Generic;

namespace sysSmartSchoolAdmin.Server.Helper
{
    public static class clsPopulator
    {

        public static List<LookUpDTO> Currency = new List<LookUpDTO>()
        {
            new LookUpDTO { Id = 0, name = "-Select-" },
            new LookUpDTO { Id = 1, name = "ZWL" },
            new LookUpDTO { Id = 2, name = "RANDS" },
            new LookUpDTO { Id = 3, name = "USD" },
            new LookUpDTO { Id = 4, name = "PULA" },
            new LookUpDTO { Id = 5, name = "POUNDS" }
        };

        public static List<LookUpDTO> TransactionTypes = new List<LookUpDTO>()
        {
            new LookUpDTO { Id = 0, name = "-Select-" },
            new LookUpDTO { Id = 1, name = "Payment" },
            new LookUpDTO { Id = 2, name = "Invoice" },
        };

    }
}
